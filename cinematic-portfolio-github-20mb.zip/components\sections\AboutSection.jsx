'use client'

import content from '@/data/content.json'
import profile from '@/data/profile.json'
import styles from '@/styles/sections/AboutSection.module.css'

export default function AboutSection({ onNavigate }) {
  return (
    <section data-nav-target="about" className={styles.section}>
      <div className={styles.header}>
        <span className={styles.eyebrow}>{content.sections.aboutEyebrow}</span>
        <h2 className={styles.title}>{content.sections.aboutTitle}</h2>
      </div>

      <div className={styles.layout}>
        <div className={styles.copyBlock}>
          <p className={styles.copy}>{profile.about}</p>
          <p className={styles.closing}>{profile.aboutClosing}</p>
          <button type="button" className={styles.cta} onClick={() => onNavigate('contact')}>
            Get in touch
          </button>
        </div>

        <div className={styles.detailBlock}>
          <div className={styles.metricGrid}>
            {profile.stats.map((stat) => (
              <div key={stat.label} className={styles.metricCard}>
                <span className={styles.metricValue}>{stat.value}</span>
                <span className={styles.metricLabel}>{stat.label}</span>
              </div>
            ))}
          </div>

          <div className={styles.capabilityList}>
            {profile.capabilities.map((capability) => (
              <div key={capability} className={styles.capability}>
                {capability}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
