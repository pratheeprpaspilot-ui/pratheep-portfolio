'use client'

import { useState } from 'react'
import { FiArrowLeft, FiArrowRight, FiArrowUpRight } from 'react-icons/fi'
import content from '@/data/content.json'
import profile from '@/data/profile.json'
import styles from '@/styles/sections/ProjectsSection.module.css'

export default function ProjectsSection({ onNavigate }) {
  const [activeReel, setActiveReel] = useState(0)
  const currentReel = profile.reels[activeReel]

  function goPrev() {
    setActiveReel((index) => (index === 0 ? profile.reels.length - 1 : index - 1))
  }

  function goNext() {
    setActiveReel((index) => (index === profile.reels.length - 1 ? 0 : index + 1))
  }

  return (
    <section data-nav-target="projects" className={styles.section}>
      <div className={styles.header}>
        <span className={styles.eyebrow}>{content.sections.projectsEyebrow}</span>
        <h2 className={styles.title}>{content.sections.projectsTitle}</h2>
      </div>

      <div className={styles.layout}>
        <div className={styles.copyBlock}>
          <div className={styles.caseMeta}>
            <span className={styles.caseNumber}>{profile.caseStudy.number}</span>
            <span className={styles.caseType}>{profile.caseStudy.type}</span>
          </div>

          <h3 className={styles.caseTitle}>{profile.caseStudy.title}</h3>
          <p className={styles.caseCopy}>{profile.caseStudy.description}</p>

          <button type="button" className={styles.caseCta} onClick={() => onNavigate('contact')}>
            {profile.caseStudy.ctaLabel}
            <FiArrowUpRight />
          </button>

          <div className={styles.selectorGrid}>
            {profile.reels.map((reel, index) => (
              <button
                key={reel.id}
                type="button"
                className={`${styles.selector} ${index === activeReel ? styles.selectorActive : ''}`}
                onClick={() => setActiveReel(index)}
              >
                {String(index + 1).padStart(2, '0')}
              </button>
            ))}
          </div>
        </div>

        <div className={styles.playerBlock}>
          <div className={styles.playerFrame}>
            {currentReel.type === 'video' ? (
              <video
                key={currentReel.id}
                src={currentReel.url}
                title={currentReel.title}
                className={styles.player}
                controls
                playsInline
              />
            ) : (
              <iframe
                key={currentReel.id}
                src={currentReel.url}
                title={currentReel.title}
                className={styles.player}
                allow="autoplay"
                allowFullScreen
              />
            )}
          </div>

          <div className={styles.playerFooter}>
            <span className={styles.playerLabel}>
              Reel {String(activeReel + 1).padStart(2, '0')} / {String(profile.reels.length).padStart(2, '0')}
            </span>

            <div className={styles.controls}>
              <button type="button" className={styles.control} onClick={goPrev} aria-label="Previous reel">
                <FiArrowLeft />
              </button>
              <button type="button" className={styles.control} onClick={goNext} aria-label="Next reel">
                <FiArrowRight />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
