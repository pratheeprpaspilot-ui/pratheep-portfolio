'use client'

import { useEffect, useRef, useState } from 'react'
import { gsap } from '@/lib/gsap'
import Navbar from '@/components/ui/Navbar'
import HeroSection from '@/components/sections/HeroSection'
import AboutSection from '@/components/sections/AboutSection'
import ServicesSection from '@/components/sections/ServicesSection'
import ProjectsSection from '@/components/sections/ProjectsSection'
import WorkExperienceSection from '@/components/sections/WorkExperienceSection'
import ContactSection from '@/components/sections/ContactSection'
import content from '@/data/content.json'
import styles from './page.module.css'

const NAV_SECTIONS = content.navigation.map((item) => item.target)

export default function Home() {
  const mainRef = useRef(null)
  const [activeSection, setActiveSection] = useState(NAV_SECTIONS[0])

  useEffect(() => {
    const scroller = mainRef.current
    if (!scroller) return

    function updateActiveSection() {
      const probe = scroller.scrollTop + window.innerHeight * 0.38
      let nextSection = NAV_SECTIONS[0]

      NAV_SECTIONS.forEach((id) => {
        const section = scroller.querySelector(`[data-nav-target="${id}"]`)
        if (section && section.offsetTop <= probe) {
          nextSection = id
        }
      })

      setActiveSection((current) => (current === nextSection ? current : nextSection))
    }

    updateActiveSection()
    scroller.addEventListener('scroll', updateActiveSection, { passive: true })
    window.addEventListener('resize', updateActiveSection)

    return () => {
      scroller.removeEventListener('scroll', updateActiveSection)
      window.removeEventListener('resize', updateActiveSection)
    }
  }, [])

  function goTo(sectionId) {
    const scroller = mainRef.current
    const target = scroller?.querySelector(`[data-nav-target="${sectionId}"]`)
    if (!scroller || !target) return

    gsap.to(scroller, {
      scrollTop: target.offsetTop - 24,
      duration: 1.05,
      ease: 'power3.inOut',
      overwrite: true,
    })
  }

  return (
    <>
      <Navbar
        items={content.navigation}
        activeSection={activeSection}
        onNavigate={goTo}
      />
      <main ref={mainRef} className={styles.main}>
        <HeroSection onNavigate={goTo} />
        <AboutSection onNavigate={goTo} />
        <ServicesSection />
        <ProjectsSection onNavigate={goTo} />
        <WorkExperienceSection />
        <ContactSection />
      </main>
    </>
  )
}
