'use client'

import Image from 'next/image'
import content from '@/data/content.json'
import profile from '@/data/profile.json'
import styles from '@/styles/sections/ServicesSection.module.css'

export default function ServicesSection() {
  return (
    <section data-nav-target="services" className={styles.section}>
      <div className={styles.header}>
        <span className={styles.eyebrow}>{content.sections.servicesEyebrow}</span>
        <h2 className={styles.title}>{content.sections.servicesTitle}</h2>
      </div>

      <div className={styles.grid}>
        {profile.services.map((service) => (
          <article key={service.id} className={styles.card}>
            <div className={styles.media}>
              <Image
                src={service.image}
                alt={service.alt}
                fill
                sizes="(max-width: 920px) 100vw, 33vw"
                className={styles.image}
              />
              <div className={styles.overlay} aria-hidden />
            </div>

            <div className={styles.body}>
              <h3 className={styles.cardTitle}>{service.title}</h3>
              <p className={styles.cardCopy}>{service.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}
