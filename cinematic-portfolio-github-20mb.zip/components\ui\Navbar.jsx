'use client'

import { useEffect, useState } from 'react'
import profile from '@/data/profile.json'
import styles from '@/styles/ui/Navbar.module.css'

export default function Navbar({ items, activeSection, onNavigate }) {
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    setMenuOpen(false)
  }, [activeSection])

  return (
    <>
      <header className={styles.header}>
        <button type="button" className={styles.brand} onClick={() => onNavigate('about')}>
          PM
        </button>

        <nav className={styles.navShell} aria-label="Primary">
          {items.map((item) => (
            <button
              key={item.target}
              type="button"
              className={`${styles.navLink} ${activeSection === item.target ? styles.active : ''}`}
              onClick={() => onNavigate(item.target)}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <a href={`mailto:${profile.email}`} className={styles.contactLink}>
          Email
        </a>

        <button
          type="button"
          className={styles.menuButton}
          onClick={() => setMenuOpen((open) => !open)}
          aria-expanded={menuOpen}
          aria-label="Toggle navigation"
        >
          <span />
          <span />
          <span />
        </button>
      </header>

      {menuOpen && (
        <div className={styles.mobileMenu}>
          {items.map((item) => (
            <button
              key={item.target}
              type="button"
              className={`${styles.mobileLink} ${activeSection === item.target ? styles.mobileActive : ''}`}
              onClick={() => onNavigate(item.target)}
            >
              {item.label}
            </button>
          ))}
          <a href={`mailto:${profile.email}`} className={styles.mobileEmail}>
            {profile.email}
          </a>
        </div>
      )}
    </>
  )
}
