'use client'

import Image from 'next/image'
import { FiArrowUpRight } from 'react-icons/fi'
import profile from '@/data/profile.json'
import styles from '@/styles/sections/HeroSection.module.css'

export default function HeroSection({ onNavigate }) {
  return (
    <section className={styles.section}>
      <div className={styles.glowPink} aria-hidden />
      <div className={styles.glowBlue} aria-hidden />

      <div className={styles.inner}>
        <div className={styles.content}>
          <span className={styles.eyebrow}>{profile.hero.eyebrow}</span>

          <div className={styles.availability}>
            <span className={styles.dot} />
            <span>{profile.hero.availability}</span>
            <span className={styles.separator} />
            <span>{profile.hero.status}</span>
          </div>

          <h1 className={styles.name}>
            <span>{profile.name.first.toUpperCase()}</span>
            <span className={styles.nameAccent}>{profile.name.last.toUpperCase()}</span>
          </h1>

          <p className={styles.copy}>{profile.hero.intro}</p>

          <div className={styles.actions}>
            <button type="button" className={styles.primaryCta} onClick={() => onNavigate('contact')}>
              {profile.hero.ctaLabel}
              <FiArrowUpRight />
            </button>
            <a href={`mailto:${profile.email}`} className={styles.secondaryCta}>
              {profile.email}
            </a>
          </div>

          <div className={styles.stats}>
            {profile.stats.map((stat) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{stat.value}</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className={styles.visual}>
          <div className={styles.portraitShell}>
            <div className={styles.portraitFrame}>
              <Image
                src={profile.hero.image}
                alt={profile.name.full}
                fill
                priority
                sizes="(max-width: 920px) 68vw, 32vw"
                className={styles.portrait}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
