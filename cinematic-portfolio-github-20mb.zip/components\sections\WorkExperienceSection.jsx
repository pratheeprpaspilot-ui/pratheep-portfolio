'use client'

import content from '@/data/content.json'
import profile from '@/data/profile.json'
import styles from '@/styles/sections/WorkExperienceSection.module.css'

export default function WorkExperienceSection() {
  return (
    <section data-nav-target="experience" className={styles.section}>
      <div className={styles.header}>
        <span className={styles.eyebrow}>{content.sections.experienceEyebrow}</span>
        <h2 className={styles.title}>{content.sections.experienceTitle}</h2>
      </div>

      <div className={styles.timeline}>
        {profile.experience.map((item) => (
          <article key={item.id} className={styles.card}>
            <div className={styles.period}>{item.period}</div>
            <div className={styles.content}>
              <span className={styles.kicker}>{item.eyebrow}</span>
              <h3 className={styles.role}>{item.role}</h3>
              <p className={styles.company}>{item.company}</p>
              <ul className={styles.bullets}>
                {item.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}
