import { ImageResponse } from 'next/og'
import profile from '@/data/profile.json'
import { SITE_URL } from '@/lib/siteConfig'

export const runtime = 'edge'

export const alt = profile.siteTitle

export const size = {
  width: 1200,
  height: 630,
}

export const contentType = 'image/png'

const photoUrl = `${SITE_URL}${profile.hero.image}`

export default function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          width: 1200,
          height: 630,
          display: 'flex',
          position: 'relative',
          overflow: 'hidden',
          background: '#060608',
          color: '#f0f0f2',
          fontFamily: 'sans-serif',
        }}
      >
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background:
              'radial-gradient(circle at 20% 80%, rgba(0, 229, 255, 0.14), transparent 32%), radial-gradient(circle at 82% 16%, rgba(255, 0, 85, 0.2), transparent 34%)',
          }}
        />

        <div
          style={{
            flex: 1,
            padding: '68px 64px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            zIndex: 1,
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 14,
                padding: '14px 22px',
                borderRadius: 999,
                border: '1px solid rgba(255,255,255,0.12)',
                background: 'rgba(17, 17, 22, 0.78)',
                color: '#9da0b1',
                fontSize: 18,
                letterSpacing: 3,
                textTransform: 'uppercase',
              }}
            >
              <span style={{ width: 8, height: 8, borderRadius: 999, background: '#00d26a' }} />
              {profile.hero.availability}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 0.86 }}>
              <span style={{ fontSize: 108, fontWeight: 900, letterSpacing: -5 }}>
                {profile.name.first.toUpperCase()}
              </span>
              <span
                style={{
                  fontSize: 108,
                  fontWeight: 900,
                  letterSpacing: -5,
                  backgroundImage: 'linear-gradient(135deg, #ff0055 0%, #7c3aed 52%, #00e5ff 100%)',
                  backgroundClip: 'text',
                  color: 'transparent',
                }}
              >
                {profile.name.last.toUpperCase()}
              </span>
            </div>

            <p
              style={{
                maxWidth: 580,
                fontSize: 26,
                lineHeight: 1.45,
                color: '#b7b9c5',
                margin: 0,
              }}
            >
              {profile.description}
            </p>
          </div>

          <div style={{ display: 'flex', gap: 22 }}>
            {profile.stats.slice(0, 3).map((stat) => (
              <div
                key={stat.label}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 8,
                  padding: '22px 24px',
                  borderRadius: 28,
                  border: '1px solid rgba(255,255,255,0.08)',
                  background: 'rgba(14, 14, 18, 0.92)',
                  minWidth: 150,
                }}
              >
                <span style={{ fontSize: 34, fontWeight: 900 }}>{stat.value}</span>
                <span
                  style={{
                    fontSize: 13,
                    letterSpacing: 1.8,
                    textTransform: 'uppercase',
                    color: '#8a8a9a',
                  }}
                >
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div
          style={{
            width: 420,
            position: 'relative',
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'center',
            zIndex: 1,
          }}
        >
          <div
            style={{
              position: 'absolute',
              inset: '72px 40px 42px 0',
              borderRadius: 40,
              background: 'linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0))',
              border: '1px solid rgba(255,255,255,0.08)',
            }}
          />
          <img
            src={photoUrl}
            width={360}
            height={470}
            alt={profile.name.full}
            style={{
              objectFit: 'contain',
              zIndex: 1,
            }}
          />
        </div>
      </div>
    ),
    size,
  )
}
