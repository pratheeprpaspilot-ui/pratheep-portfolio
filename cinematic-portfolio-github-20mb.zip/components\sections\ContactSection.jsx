'use client'

import { FaEnvelope, FaInstagram, FaLinkedinIn } from 'react-icons/fa'
import { SiFiverr, SiUpwork } from 'react-icons/si'
import profile from '@/data/profile.json'
import styles from '@/styles/sections/ContactSection.module.css'

const SOCIAL_ICONS = {
  Instagram: FaInstagram,
  LinkedIn: FaLinkedinIn,
  Upwork: SiUpwork,
  Fiverr: SiFiverr,
}

export default function ContactSection() {
  function handleSubmit(event) {
    event.preventDefault()

    const formData = new FormData(event.currentTarget)
    const name = formData.get('name')?.toString().trim() || 'Portfolio inquiry'
    const contact = formData.get('contact')?.toString().trim() || ''
    const project = formData.get('project')?.toString().trim() || ''

    const subject = `Portfolio inquiry from ${name}`
    const body = [
      `Name: ${name}`,
      `Contact: ${contact || 'Not provided'}`,
      '',
      'Project details:',
      project || 'Not provided',
    ].join('\n')

    window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }

  return (
    <section data-nav-target="contact" className={styles.section}>
      <div className={styles.header}>
        <h2 className={styles.title}>{profile.contact.heading}</h2>
        <p className={styles.copy}>{profile.contact.intro}</p>
      </div>

      <div className={styles.layout}>
        <form className={styles.form} onSubmit={handleSubmit}>
          <label className={styles.field}>
            <span>Your Name</span>
            <input type="text" name="name" placeholder="Your Name" required />
          </label>

          <label className={styles.field}>
            <span>Contact Details</span>
            <input type="text" name="contact" placeholder="Email / Phone" required />
          </label>

          <label className={styles.field}>
            <span>Project Purpose</span>
            <textarea
              name="project"
              placeholder="What are you looking for?"
              rows="6"
              required
            />
          </label>

          <button type="submit" className={styles.submit}>
            {profile.contact.ctaLabel}
          </button>
        </form>

        <aside className={styles.sidebar}>
          <div className={styles.identity}>
            <span className={styles.role}>{profile.roles.detailed}</span>
            <h3 className={styles.name}>{profile.name.full.toUpperCase()}</h3>
          </div>

          <div className={styles.infoBlock}>
            <p className={styles.infoHeading}>{profile.contact.socialHeading}</p>
            <div className={styles.socials}>
              {profile.socials.map((social) => {
                const Icon = SOCIAL_ICONS[social.label]
                return (
                  <a key={social.label} href={social.href} target="_blank" rel="noreferrer" className={styles.socialLink}>
                    <span className={styles.socialIcon}>{Icon ? <Icon /> : null}</span>
                    <span>{social.label}</span>
                  </a>
                )
              })}
            </div>
          </div>

          <div className={styles.infoBlock}>
            <p className={styles.infoHeading}>{profile.contact.locationHeading}</p>
            <a href={`mailto:${profile.email}`} className={styles.contactRow}>
              <FaEnvelope />
              <span>{profile.email}</span>
            </a>
            <p className={styles.location}>{profile.location.based}</p>
          </div>
        </aside>
      </div>
    </section>
  )
}
